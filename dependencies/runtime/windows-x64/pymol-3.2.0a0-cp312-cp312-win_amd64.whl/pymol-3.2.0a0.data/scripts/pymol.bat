"%~dp0\..\..\..\..\..\..\viewer\python.exe" "%~dp0\..\..\..\..\..\..\viewer\Lib\site-packages\pymol\__init__.py" %*
